For Windows Please install:
- Microsoft .Net Framework 4.0
- Microsoft Visual C++ 2010 x86 Redistributable Package

For Linux:
-Please compile by yourself 