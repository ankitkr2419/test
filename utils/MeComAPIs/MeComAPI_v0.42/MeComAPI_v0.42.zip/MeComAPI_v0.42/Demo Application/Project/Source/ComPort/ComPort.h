extern void ComPort_Open(int PortNr, int Speed);
extern void ComPort_Close(void);
extern void ComPort_Send(char *in);
